[Management.ManagementDateTimeConverter]::ToDateTime($Win32_OperatingSystem.installdate)
